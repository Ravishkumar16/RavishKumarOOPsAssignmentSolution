package com.greatLearning.Driver;

import com.greatLearning.department.AdminDepartment;
import com.greatLearning.department.HRDepartment;
import com.greatLearning.department.TechDepartment;

public class driver {
	
	public static void main (String args[]){
		
		HRDepartment hr = new HRDepartment();
		
		TechDepartment tech = new TechDepartment();
		
		AdminDepartment admin = new AdminDepartment();
		
		admin.departmentName();
		admin.getTodaysWork();
		admin.getWorkDeadline();
		admin.isTodayAHoliday();
		
		hr.departmentName();
		hr.doActivity();
		hr.getTodaysWork();
		hr.getWorkDeadline();
		hr.isTodayAHoliday();
		
		tech.departmentName();
		tech.getTodaysWork();
		tech.getWorkDeadline();
		tech.getTechStackInformation();
		tech.isTodayAHoliday();
	}

}

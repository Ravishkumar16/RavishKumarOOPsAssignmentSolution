package com.greatLearning.department;

public class TechDepartment extends SuperDepartment {

	public void departmentName (){
		String deptName = "Tech Department";
		System.out.println("");
		System.out.println("Welcome to "+deptName);

		
	}
	public void getTodaysWork (){
		String todaysWorks = "Complete coding of module 1";
		System.out.println(todaysWorks);
		
	}
	
	public void getWorkDeadline(){
		String deadLine = "Complete by EOD";
		System.out.println(deadLine);
		
	}
	public void getTechStackInformation (){
		String stackinfo = "core Java";
		System.out.println(stackinfo);
		
	}
}

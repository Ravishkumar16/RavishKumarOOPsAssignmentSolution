package com.greatLearning.department;

public class HRDepartment extends SuperDepartment {

	public void departmentName (){
		String deptName = "Hr Department";
		System.out.println("");
		System.out.println("Welcome to "+deptName);

		
	}
	public void getTodaysWork (){
		String todaysWorks = "Fill today�s timesheet and mark your attendance";
		System.out.println(todaysWorks);
		
	}
	
	public void getWorkDeadline(){
		String deadLine = "Complete by EOD";
		System.out.println(deadLine);
		
	}
	public void doActivity(){
		String activity = "team Lunch";
		System.out.println(activity);
		
	}
}

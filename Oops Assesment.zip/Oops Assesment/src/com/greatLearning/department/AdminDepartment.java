package com.greatLearning.department;

public class AdminDepartment extends SuperDepartment {

	public void departmentName (){
		String deptName = "Admin Department";
		System.out.println("");
		System.out.println("Welcome to "+deptName);
	
	}
	public void getTodaysWork (){
		String todaysWorks = "Complete your documents Submission";
		System.out.println(todaysWorks);
		
	}
	
	public void getWorkDeadline(){
		String deadLine = "Complete by EOD";
		System.out.println(deadLine);
		
	}
}

package com.greatLearning.department;

public class SuperDepartment {

	public void departmentName (){
		String deptName = "Super Department";
		System.out.println(deptName);
				
	}
	public void getTodaysWork (){
		String todaysWorks = "No Work as of now";
		System.out.println(todaysWorks);
		
	}
	
	public void getWorkDeadline(){
		String deadLine = "Nill";
		System.out.println(deadLine);
		
	}
	public void isTodayAHoliday(){
		String isHolday = "Today is not a holiday";
		System.out.println(isHolday);
		
	}
	
}
